import React from 'react'


const Tip = ()=>{
    
    return <>
        <h3>新型肺炎预防须知</h3>
    </>
}


export default Tip
